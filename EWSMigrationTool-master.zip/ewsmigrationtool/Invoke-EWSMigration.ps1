param (
	[string]$SourceMailbox,	
	[string]$SourceFolder = "Top of Information Store",
    $SourceCredential,
	
    [string]$TargetMailbox,
	[string]$TargetFolder  = "Top of Information Store",
    $TargetCredential,


	[string]$SourceEwsUrl,
    [string]$TargetEwsUrl,
    [string]$EWSManagedApiPath = "$PSScriptRoot\lib\EWS\Microsoft.Exchange.WebServices.dll",
	[switch]$IgnoreSSLCertificate = $true,
	[switch]$LogVerbose = $true,
    [switch]$MigrateDeletedItems = $true
);


Function LoadEWSManagedAPI()
{
	# Find and load the managed API
	
	if ( ![string]::IsNullOrEmpty($EWSManagedApiPath) )
	{
		if ( { Test-Path $EWSManagedApiPath } )
		{
			Add-Type -Path $EWSManagedApiPath
			return $true
		}
		Write-Log -Level "ERROR" ( [string]::Format("MB: $TargetMailbox - Managed API not found at specified location: {0}", $EWSManagedApiPath) ) -ForegroundColor Yellow
	}
	
	$a = Get-ChildItem -Recurse "C:\Program Files (x86)\Microsoft\Exchange\Web Services" -ErrorAction SilentlyContinue | Where-Object { ($_.PSIsContainer -eq $false) -and ( $_.Name -eq "Microsoft.Exchange.WebServices.dll" ) }
	if (!$a)
	{
		$a = Get-ChildItem -Recurse "C:\Program Files\Microsoft\Exchange\Web Services" -ErrorAction SilentlyContinue | Where-Object { ($_.PSIsContainer -eq $false) -and ( $_.Name -eq "Microsoft.Exchange.WebServices.dll" ) }
	}
	
	if ($a)	
	{
		# Load EWS Managed API
		Write-Log -Level "DEBUG" ([string]::Format("MB: $TargetMailbox - Using managed API {0} found at: {1}", $a.VersionInfo.FileVersion, $a.VersionInfo.FileName)) -ForegroundColor Gray
		Add-Type -Path $a.VersionInfo.FileName
		return $true
	}
	return $false
}

Function TrustAllCerts() {
    <#
    .SYNOPSIS
    Set certificate trust policy to trust self-signed certificates (for test servers).
    #>

    ## Code From http://poshcode.org/624
    ## Create a compilation environment
    $Provider=New-Object Microsoft.CSharp.CSharpCodeProvider
    $Compiler=$Provider.CreateCompiler()
    $Params=New-Object System.CodeDom.Compiler.CompilerParameters
    $Params.GenerateExecutable=$False
    $Params.GenerateInMemory=$True
    $Params.IncludeDebugInformation=$False
    $Params.ReferencedAssemblies.Add("System.DLL") | Out-Null

    $TASource=@'
        namespace Local.ToolkitExtensions.Net.CertificatePolicy {
        public class TrustAll : System.Net.ICertificatePolicy {
            public TrustAll()
            { 
            }
            public bool CheckValidationResult(System.Net.ServicePoint sp,
                                                System.Security.Cryptography.X509Certificates.X509Certificate cert, 
                                                System.Net.WebRequest req, int problem)
            {
                return true;
            }
        }
        }
'@ 
    $TAResults=$Provider.CompileAssemblyFromSource($Params,$TASource)
    $TAAssembly=$TAResults.CompiledAssembly

    ## We now create an instance of the TrustAll and attach it to the ServicePointManager
    $TrustAll=$TAAssembly.CreateInstance("Local.ToolkitExtensions.Net.CertificatePolicy.TrustAll")
    [System.Net.ServicePointManager]::CertificatePolicy=$TrustAll
}

Function Get-ItemExpReq {
    Param (
        $ItemIds
    )

    $result = @"
<?xml version="1.0" encoding="utf-8" ?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
xmlns:xsd="http://www.w3.org/2001/XMLSchema"
xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
xmlns:t="http://schemas.microsoft.com/exchange/services/2006/types"
xmlns:m="http://schemas.microsoft.com/exchange/services/2006/messages">
<soap:Header>
<t:RequestServerVersion Version="Exchange2010_SP1" />
</soap:Header>
<soap:Body>
<m:ExportItems>
<m:ItemIds>
$(foreach($itemId in $itemIds) {"<t:ItemId Id=`"$itemId`"/>"})
</m:ItemIds>
</m:ExportItems>
</soap:Body>
</soap:Envelope>
"@
    
    return $result
}

Function Export-MBObject {
    Param (
        $requestXML
    )

    $exportUri = New-Object System.Uri($sourceEWSUrl)
    $ewsRequest = [System.Net.WebRequest]::Create($exportUri)
    $ewsRequest.KeepAlive = $false
    $ewsRequest.Headers.Set("Pragma", "no-cache")
    $ewsRequest.Headers.Set("Translate", "f")
    $ewsRequest.Headers.Set("Depth", "0")
    $ewsRequest.ContentType = "text/xml"
    $ewsRequest.ContentLength = $requestXML.Length
    $ewsRequest.Timeout = 60000
    $ewsRequest.Method = "POST"
    $ewsRequest.Credentials = $SourceCredential.GetNetworkCredential()

    $byteQuery = [System.Text.Encoding]::ASCII.GetBytes($requestXML)
    $ewsRequest.ContentLength = $byteQuery.Length
    $requestStream = $ewsRequest.GetRequestStream()
    $requestStream.Write($byteQuery, 0, $byteQuery.Length)
    $requestStream.Close()
    
    $ewsResponse = $ewsRequest.GetResponse()
    $responseStream = $ewsResponse.GetResponseStream()
    $streamReader = New-Object System.IO.StreamReader($responseStream)
    $responseDoc = New-Object System.Xml.XmlDocument
    $responseDoc.LoadXml($streamReader.ReadToEnd())

    $responseData = @($responseDoc.GetElementsByTagName("m:Data"))
    if ($responseData.Length -ne 0) {
        #$result = [System.Convert]::FromBase64String($responseData[0].'#text')
        $result = $responseData | %{$_.'#text'}
    } else {
        $result = $false
    }

    $responseStream.Close()
    $streamReader.Close()
    $responseData = $null
    $responseDoc = $null

    return $result


}

Function Get-ItemImportReq {
    Param (
        $itemData,
        $folderId
    )
    
    $result = @"
<?xml version="1.0" encoding="utf-8" ?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
               xmlns:xsd="http://www.w3.org/2001/XMLSchema"
               xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
               xmlns:t="http://schemas.microsoft.com/exchange/services/2006/types"
               xmlns:m="http://schemas.microsoft.com/exchange/services/2006/messages">
  <soap:Header>
    <t:RequestServerVersion Version="Exchange2013" />
  </soap:Header>
  <soap:Body>
    <m:UploadItems>
      <m:Items>
      $(foreach($item in $itemData) {
        "<t:Item CreateAction=`"CreateNew`">"
          "<t:ParentFolderId Id=`"$($folderId)`" />"
          "<t:Data>"
            "$($item)"
          "</t:Data>"
        "</t:Item>"})
      </m:Items>
    </m:UploadItems>
  </soap:Body>
</soap:Envelope>
"@

    return $result

}

Function Import-MBObject {
    Param (
        $requestXML
    )

    $importUri = New-Object System.Uri($targetEWSUrl)
    $ewsRequest = [System.Net.WebRequest]::Create($importUri)
    $ewsRequest.KeepAlive = $false
    $ewsRequest.Headers.Set("Pragma", "no-cache")
    $ewsRequest.Headers.Set("Translate", "f")
    $ewsRequest.Headers.Set("Depth", "0")
    $ewsRequest.ContentType = "text/xml"
    $ewsRequest.ContentLength = $requestXML.Length
    $ewsRequest.Timeout = 60000
    $ewsRequest.Method = "POST"
    $ewsRequest.Credentials = $targetCredential.GetNetworkCredential()


    $byteQuery = [System.Text.Encoding]::ASCII.GetBytes($requestXML)
    $ewsRequest.ContentLength = $byteQuery.Length
    $requestStream = $ewsRequest.GetRequestStream()
    $requestStream.Write($byteQuery, 0, $byteQuery.Length)
    $requestStream.Close()
    
    $ewsResponse = $ewsRequest.GetResponse()
    $responseStream = $ewsResponse.GetResponseStream()
    $streamReader = New-Object System.IO.StreamReader($responseStream)
    $responseDoc = New-Object System.Xml.XmlDocument
    $responseDoc.LoadXml($streamReader.ReadToEnd())

    $responseData = @($responseDoc.GetElementsByTagName("m:UploadItemsResponseMessage"))
    if ($responseData.Length -ne 0) {
        $result = $responseData | Where {$_.ResponseClass -ne "Success"}
        If(!$result) {
            $result = $true
        }
    } else {
        $result = $false
    }

    $responseStream.Close()
    $streamReader.Close()
    $responseData = $null
    $responseDoc = $null

    return $result

}

Function MoveItems {
    Param (
        $SourceFolderObj,
        $TargetFolderObj
    )

    $offset = 0
    $pageSize = 100
    $moreItems = $true
    $skip = $false
    $skipReason = ""
    $ProcessSubfolders = $true

    switch ($SourceFolderObj.DisplayName) {
        "Top of Information Store" {
            $skip = $true
            $skipReason ="Can't sync System Folders"
            $ProcessSubfolders = $false
        }
        "Conversation Action Settings" {
            $skip = $true
            $skipReason ="Can't sync System Folders"
            $ProcessSubfolders = $false
        }
        "Conflicts" {
            $skip = $true
            $skipReason ="Can't sync System Folders"
            $ProcessSubfolders = $false
        }
        "Local Failures" {
            $skip = $true
            $skipReason ="Can't sync System Folders"
            $ProcessSubfolders = $false
        }
        "Server Failures" {
            $skip = $true
            $skipReason ="Can't sync System Folders"
            $ProcessSubfolders = $false
        }
        "Journal" {
            $skip = $true
            $skipReason ="Can't sync System Folders"
            $ProcessSubfolders = $false
        }
        "News Feed" {
            $skip = $true
            $skipReason ="Can't sync System Folders"
            $ProcessSubfolders = $false    
        }
        "Suggested Contacts" {
            $skip = $true
            $skipReason ="Can't sync System Folders"
            $ProcessSubfolders = $false
        }
        "Sync Issues" {
            $skip = $true
            $skipReason ="Can't sync System Folders"
            $ProcessSubfolders = $false
        }
        "Scheduled" {
            $skip = $true
            $skipReason ="Can't sync System Folders"
            $ProcessSubfolders = $false
        }

        ## TODO Add Exclusion from Migration CSV

        {$SourceFolderObj.FolderClass -eq "IPF.Contact"} {
            $skip = $true
            $skipReason ="Contact folders sync by different method"
            $Script:ContactFolders += $SourceFolderObj    
        }
    }


    If ($SourceFolderObj.TotalCount -gt 0 -and !$skip) {
        $totalCount = $SourceFolderObj.TotalCount
        Write-Log -Level "INFO" "MB: $TargetMailbox - Starting migration of $($sourceFolderObj.TotalCount) items from $($sourceFolderObj.DisplayName)"

        While($moreItems) {
            $view = New-Object Microsoft.Exchange.WebServices.Data.ItemView($pageSize, $offset, [Microsoft.Exchange.WebServices.Data.OffsetBasePoint]::Beginning)
            $View.OrderBy.add([Microsoft.Exchange.WebServices.Data.ItemSchema]::DateTimeReceived, [Microsoft.Exchange.WebServices.Data.SortDirection]::Ascending)
            $view.PropertySet = New-Object Microsoft.Exchange.WebServices.Data.PropertySet([Microsoft.Exchange.WebServices.Data.BasePropertySet]::IdOnly)
            $results = $sourceFolderObj.FindItems($view)

            try {
                $importIds = @()
                Write-Log -Level "DEBUG" "MB: $TargetMailbox - Starting batch processing at $offset to $($offset + $pageSize) items"

                foreach($item in $results.Items){
                    $importIds += $item.Id
                }
                
                $msgsToExport = Get-ItemExpReq -ItemIds $importIds
                $msgsToImport = Export-MBObject -requestXML $msgsToExport

                $newMsgReqs = Get-ItemImportReq -itemData $msgsToImport -folderId $TargetFolderObj.Id
                $newMsgImport = Import-MBObject -requestXML $newMsgReqs
                If(!$newMsgImport) {
                    Write-Log -Level "ERROR" "MB: $TargetMailbox - Failed to Import messages $offset through $($offset + $pageSize)"
                } elseif ($newMsgImport -eq $true) {
                    Write-Log -Level "DEBUG" "MB: $TargetMailbox - Successfully Imported messages $offset through $($offset + $pageSize)"
                } else {
                    Write-Log -Level "ERROR" "MB: $TargetMailbox - Failed to Import $newMsgImport.Count messages in batch $offset through $($offset + $pageSize)"
                }
            }
            catch {
                Write-Log -Level "ERROR" "MB: $TargetMailbox - $_"
            }
        
            $moreItems = $results.MoreAvailable
            #$moreItems = $false
            $offset += $pageSize
        }

        Write-Log -Level "INFO" "MB: $TargetMailbox - Finished migrating $($sourceFolderObj.DisplayName)."

    } Else {
        If ($skip) { 
            Write-Log -Level "INFO" "MB: $TargetMailbox - Skipping $($sourceFolderObj.DisplayName). Reason: $skipReason"
        } Else {
            Write-Log -Level "INFO" "MB: $TargetMailbox - No items to migrate in $($sourceFolderObj.DisplayName)."
        }
    }

    

    Write-Log -Level "Debug" "MB: $TargetMailbox - Searching for subfolders in $($sourceFolderObj.DisplayName)."
    If ($SourceFolderObj.ChildFolderCount -gt 0) {
        $folderView = New-Object Microsoft.Exchange.WebServices.Data.FolderView(1000)
        $subFolderResults = $sourceFolderObj.FindFolders($folderView)
        foreach($subFolder in $subFolderResults) {

            $filter = New-Object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo([Microsoft.Exchange.WebServices.Data.FolderSchema]::DisplayName, $subFolder.DisplayName)
            $folderView = New-Object Microsoft.Exchange.WebServices.Data.FolderView(2)
            $findFolderResults = $TargetFolderObj.FindFolders($filter,$folderView)
            
            if ($findFolderResults.TotalCount -eq 0) {
                try {
                    $targetSubfolder = New-Object Microsoft.Exchange.WebServices.Data.Folder($targetService)
                    $targetSubfolder.DisplayName = $subFolder.DisplayName
                    $targetSubfolder.FolderClass = $subFolder.FolderClass
                    $targetSubFolder.Save($targetFolderObj.Id)
                }
                catch {
                    Write-Log -Level ERROR -Message "MB: $TargetMailbox - Error creating $($subfolder.DisplayName): $_"
                }
            } else {
                $targetSubFolder = $findFolderResults.Folders[0]
            }
            
            MoveItems -SourceFolderObj $subFolder -TargetFolderObj $targetSubFolder

        }
    } else {
        Write-Log -Level "Debug" "MB: $TargetMailbox - No subfolders in $($sourceFolderObj.DisplayName)."
    }

}

Function SyncContacts {
    Param(
        $SourceContactFolder,
        $TargetContactFolder
    )
    
    $offset = 0
    $pageSize = 50
    $moreItems = $true

    Write-Log -Level "INFO" "MB: $TargetMailbox - Starting migration of $($sourceContactFolder.TotalCount) items from $($sourceContactFolder.DisplayName)"

    If($SourceContactFolder.TotalCount -gt 0) {
        While($moreItems) {
            Write-Log -Level "DEBUG" "MB: $TargetMailbox - Starting batch processing at $offset to $($offset + $pageSize) items"
            
            try {
                $view = New-Object Microsoft.Exchange.WebServices.Data.ItemView($pageSize, $offset, [Microsoft.Exchange.WebServices.Data.OffsetBasePoint]::Beginning)
                $view.PropertySet = New-Object Microsoft.Exchange.WebServices.Data.PropertySet([Microsoft.Exchange.WebServices.Data.BasePropertySet]::IdOnly)
                $results = $SourceContactFolder.FindItems($view)

                foreach ($contact in $results) {
                    $props = New-Object Microsoft.Exchange.WebServices.Data.PropertySet([Microsoft.Exchange.WebServices.Data.ContactSchema]::MimeContent)
                    $srcContact = [Microsoft.Exchange.WebServices.Data.Contact]::Bind($sourceService, $contact.Id, $props) 
                    $newContact = New-Object Microsoft.Exchange.WebServices.Data.Contact($targetService)
                    $newContact.MimeContent = $srcContact.MimeContent
                }
            }
            catch {
                Write-Log -Level "ERROR" "MB: $TargetMailbox - $_"
            }    
            $moreItems = $results.MoreAvailable
            $offset += $pageSize
        }
        Write-Log -Level "INFO" "MB: $TargetMailbox - Finished migrating $($sourceFolderObj.DisplayName)."
    }

}


Function GetFolder {
    Param (
        $RootFolder,
        $FolderPath,
        $service,
        [switch]$createIfMissing = $false
    )
	
	$Folder = $RootFolder;
	if ($FolderPath -ne '\')
	{
		$PathElements = $FolderPath -split '\\';
		For ($i=0; $i -lt $PathElements.Count; $i++)
		{
			if ($PathElements[$i])
			{
				$View = New-Object  Microsoft.Exchange.WebServices.Data.FolderView(2,0)
				$View.PropertySet = [Microsoft.Exchange.WebServices.Data.BasePropertySet]::IdOnly
						
				$SearchFilter = New-Object Microsoft.Exchange.WebServices.Data.SearchFilter+IsEqualTo([Microsoft.Exchange.WebServices.Data.FolderSchema]::DisplayName, $PathElements[$i])
				
				$FolderResults = $Folder.FindFolders($SearchFilter, $View)
				if ($FolderResults.TotalCount -gt 1)
				{
					# We have either none or more than one folder returned... Either way, we can't continue
					$Folder = $null;
					Write-Log -Level "ERROR" "MB: $TargetMailbox - Failed to find " $PathElements[$i]
					Write-Log -Level "ERROR" "MB: $TargetMailbox - Requested folder path: " $FolderPath
					break;
				} elseif ($FolderResults.TotalCount -eq 0 -and $createIfMissing) {
                    $newFolder = New-Object Microsoft.Exchange.WebServices.Data.Folder($targetService)
                    $newFolder.DisplayName = $PathElements[$i]
                    $newFolder.Save($targetFolderObj.Id)
                    $Folder = $newFolder
                }
				
				$Folder = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($service, $FolderResults.Folders[0].Id)
			}
		}
	}
	
	return $Folder
}

##########################################################################
##  START OF SCRIPT
##########################################################################


# Setup Logging

Import-Module "$PSScriptRoot\lib\Logging\2.4.4\Logging.psm1"
Set-LoggingDefaultLevel -Level "INFO"

If($LogVerbose) {
    Add-LoggingTarget -Name File -Configuration @{Level = "DEBUG"; Path = "$PSScriptRoot\logs\$($sourceMailbox)_%{+%Y%m%d}.log"; Append = $true}
} Else {

    Add-LoggingTarget -Name File -Configuration @{Level = "INFO"; Path = "$PSScriptRoot\logs\$($sourceMailbox)_%{+%Y%m%d}.log"; Append = $true}
}

Add-LoggingTarget -Name RocketChat -Configuration @{
    Level = "INFO"
    ServerURI = "https://rocketchat.radpartners.com/hooks/6id4C77GjS42fdrjx/TRJYQ732E5aR8x5DWRDiwLNowtiBjgNTQ35EftAvYvPqcfLw"
    Format = "* %{level} * - %{message}"
    Channel = "#it_mail_migrations"
}

Write-Log -Level "INFO" "Starting migration for $sourceMailbox to $targetMailbox"

# Rackspace API Setup

. "$PSScriptRoot\lib\Rackspace-ExchApiWrapper.ps1"

#$userKey = "VNFfRRxbY83XQzKSFR5K"
#$secretKey = "vXLmnPsJJcBY56WFtVRJTY/3DvV741Nnb89Jqbt7"
#$userAgent = ([Microsoft.PowerShell.Commands.PSUserAgent]::Chrome)
#$apiBaseUri = "https://api.emailsrvr.com/v1/customers/1330469/domains/radpartners.com"
#$apiMbUri = $apiBaseUri + "/ex/mailboxes"
#$apiContactsUri = $apiBaseUri + "/ex/contacts"

# EWS Setup

if ($IgnoreSSLCertificate) {
    Write-Log -Level "WARNING" "MB: $TargetMailbox - Ignore untrusted SSL enabled. Hold on to your butts..."
    TrustAllCerts
}

if (!(LoadEWSManagedAPI)) {
    Write-Log -Level "ERROR" "MB: $TargetMailbox - Can't find EWS components at $EWSManagedApiPath. Exiting."
    Exit
}

Write-Log -Level "DEBUG" "MB: $TargetMailbox - EWS managed API loaded. Creating source and destination services" 
$sourceService = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService([Microsoft.Exchange.Webservices.Data.ExchangeVersion]::Exchange2010_SP2)
$targetService = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService([Microsoft.Exchange.Webservices.Data.ExchangeVersion]::Exchange2013)

# Source Mailbox Setup

Write-Log -Level "DEBUG" "MB: $TargetMailbox - Importing Source Server Credentails" 
if ($sourceCredential) {
    $sourceService.UseDefaultCredentials = $false
    $sourceService.Credentials = $sourceCredential.GetNetworkCredential()
}
Write-Log -Level "DEBUG" "MB: $TargetMailbox - Setting Source service URI to $sourceEwsUrl"
$sourceService.Url = New-Object Uri($sourceEwsUrl)

Write-Log -Level "DEBUG" "MB: $TargetMailbox - Getting Source Mail folders" 
#$sourceService.ImpersonatedUserId = New-Object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress, $SourceMailbox)
#$sourceRoot = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($sourceService, [Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Root)
$sourceFID = New-Object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Root, $SourceMailbox)
$sourceRoot = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($sourceService, $sourceFID)

$sourceObj = GetFolder $sourceRoot $sourceFolder $sourceService

if(!$sourceObj) {
    Write-Log -Level "ERROR" "MB: $TargetMailbox - Could not connect to source mailbox. Exiting"
    Exit
} else {
    Write-Log -Level "INFO" "MB: $TargetMailbox - Successfully connected to source mailbox."
}

# Target Mailbox Setup

Write-Log -Level "DEBUG" "Importing Target Server Credentials"
if ($targetCredential) {
    $targetService.UseDefaultCredentials = $false
    $targetService.Credentials = $targetCredential.GetNetworkCredential()
}

Write-Log -Level "INFO" "MB: $TargetMailbox - Setting permissions on target mailbox"
Grant-RSMbPermission -mailboxName $TargetMailbox.Split("@")[0] -permissionUser $targetCredential.Username.Split("@")[0]
Write-Log -Level "INFO" "MB: $TargetMailbox - Delay 15 minutes to ensure permissions are active"
Start-Sleep -Seconds 900
Write-Log -Level "INFO" "MB: $TargetMailbox - Resuming migration"

Write-Log -Level "DEBUG" "Setting Source service URI to $targetEwsUrl"
$targetService.Url = New-Object Uri($targetEwsUrl)

Write-Log -Level "DEBUG" "Getting Target Mail folders" 
#$targetService.ImpersonatedUserId = New-Object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress, $TargetMailbox);
#$targetRoot = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($targetService, [Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Root)
$targetFID = New-Object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Root, $TargetMailbox)
$targetRoot = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($targetService, $targetFID)
$targetObj = GetFolder $targetRoot $targetFolder $targetService

if(!$targetObj) {
    Write-Log -Level "ERROR" "MB: $TargetMailbox - Could not connect to target mailbox. Exiting"
    Exit
} else {
    Write-Log -Level "INFO" "MB: $TargetMailbox - Successfully connected to target mailbox."
}

# Start Migration Process

Write-Log -Level "INFO" "MB: $TargetMailbox - Starting migration process"

$Script:ContactFolders = @()

Write-Log -Level "INFO" "MB: $TargetMailbox - Starting email and calendar item migration"
MoveItems -SourceFolderObj $sourceObj -TargetFolderObj $targetObj

If ($ContactFolders.Count -gt 0) {
    Write-Log -Level "INFO" "MB: $TargetMailbox - Starting contact migration"
    foreach ($cFolder in $Script:ContactFolders) {
        $targetCFolder = GetFolder -RootFolder $targetObj -FolderPath $cFolder.DisplayName -service $targetService -createIfMissing
        SyncContacts -SourceContactFolder $cFolder -TargetContactFolder $targetCFolder 
    }
}

Write-Log -Level INFO -Message "MB: $TargetMailbox - Item migration tasks complete."

Write-Log -Level INFO -Message "MB: $TargetMailbox - Checking to see if the target mailbox is forwarded"
$rsMailbox = Get-RSMailbox -mailboxName $TargetMailbox.Split("@")[0]
if ($rsMailbox) {
    if ($rsMailbox.emailForwardingaddress) {
        Write-Log -Level INFO -Message "MB: $TargetMailbox - Removing forwarding to $($rsMailbox.emailForwardingAddress)"
        Set-RSMBFWDAddress -mbName $rsMailbox.name -fwdAddress ""
    }
} 

Write-Log -Level "DEBUG" "MB: $TargetMailbox - Removing target mailbox permissions"
Remove-RSMbPermission -mailboxName $TargetMailbox.Split("@")[0] -permissionUser $targetCredential.Username.Split("@")[0]

Write-Log -Level "INFO" "MB: $TargetMailbox - All steps complete. Review any errors above for status of item migration"

Remove-Module Logging