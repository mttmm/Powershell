Param(
    $credTarget = "CRC"
)

$cred = Get-Credential -Message "Enter your credentials for $credTarget"
if ($cred.UserName.Contains("\")) {
    $username = $cred.UserName.Split("\")[1]
} elseif ($cred.UserName.Contains("@")) {
    $username = $cred.UserName.Split("@")[0]
} else {
    $username = $cred.UserName
}

$cred | Export-Clixml "$PSScriptRoot\creds\$credTarget.$username.credential"