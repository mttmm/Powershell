@{
    Name = 'RocketChat'
    Configuration = @{
        ServerUri   = @{Required = $true;   Type = [string]}
        BotName     = @{Required = $false;  Type = [string]}
        Channel     = @{Required = $false;  Type = [string]}
        Level       = @{Required = $false;  Type = [string]}
        Format      = @{Required = $false;  Type = [string]}
    }
    Logger = {
        param(
            $Log,
            $Format,
            $Configuration
        )

        $Text = @{
            text = Replace-Token -String $Format -Source $Log
        }

        if ($Configuration.BotName) { $Text['username'] = $Configuration.BotName }

        if ($Configuration.Channel) { $Text['channel'] = $Configuration.Channel }

        if ($Log.levelno -ge 30 -and $Log.levelno -lt 40) {
            $Text['text'] = ':warning: ' + $Text['text']
        } elseif ($Log.levelno -ge 40) {
            $Text['text'] = ':x: ' + $Text['text']
        } else {
            $Text['text'] = ':information_source: ' + $Text['text']
        }

        Invoke-RestMethod -Method Post -Uri $Configuration.ServerUri -Body ("payload=$($Text | ConvertTo-Json)") | Out-Null
    }
}