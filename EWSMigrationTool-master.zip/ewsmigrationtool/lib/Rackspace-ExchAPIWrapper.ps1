﻿Function Get-SignatureHash {
    Param(
        [String] $signatureData
    )

	$byteArray = [System.Text.Encoding]::ASCII.GetBytes($signatureData)
	$sha =  New-Object -TypeName System.Security.Cryptography.SHA1CryptoServiceProvider
	$result = $sha.ComputeHash($byteArray)
	$signature = [System.Convert]::ToBase64String($result)

	return $signature
}

Function Get-Header {

	$dateTime = (Get-Date).ToString("yyyyMMddHHmmss")
	$signatureData = "$userKey$userAgent$dateTime$secretKey"
	$hashSecret = Get-SignatureHash($signatureData)
	$xApiSignature = "$userKey`:$datetime`:$hashSecret"
	$header = @{"X-Api-Signature"="$xApiSignature"}
    $header.Add("Accept","application/json")

	return $header

}

Function Set-RSMBFWDAddress {
    Param (
        $mbName,
        $fwdAddress
    )

    $mailboxUri = $baseUri + "/ex/mailboxes/$mbName"

    $reqBody = @{emailForwardingAddress = $fwdAddress}

    $fwdOp = Invoke-RestMethod -Method Put -Uri $mailboxUri -headers $(Get-Header) -ContentType "application/x-www-form-urlencoded" -UserAgent $userAgent -Body $reqBody

    return $fwdOp

}

Function New-RSContact {
    Param (
        $contactHT,
        $contactName
    )

    $reqBody = $contactHT
    $contactUri = $contactsUri + "/" + $contactName

    $conOp = Invoke-RestMethod -Method Post -Uri $contactUri -Headers $(Get-Header) -ContentType "application/x-www-form-urlencoded" -UserAgent $userAgent -Body $reqBody

    return $conOp

}

Function Get-RSMailbox {
    Param (
        $mailboxName
    )

    $mailboxUri = $mbBaseUri + "/" + $mailboxName

    $mbGet = Invoke-RestMethod -Method Get -Uri $mailboxUri -Headers $(Get-Header) -ContentType "application/json" -UserAgent $userAgent

    return $mbGet

}

Function Get-RSMailboxes {
    Param (
        $mailboxList
    )

    $result = @()
    foreach ($mb in $mailboxList) {
        $result += Get-RSMailbox -mailboxName $mb.name
        start-sleep -Milliseconds 100
    }

    return $result
        
}

Function Get-RSMBList {
    Param (
        [switch]$all,
        [switch]$enabled,
        [MBListFields[]]$fields,
        $offset = 0,
        $size = 200
    )
    
    $fieldSep = "?"
    $reqUri = $mbBaseUri
    
    If ($enabled) {
        $fieldSep = "&"
        $reqUri = $reqUri + "?enabled=true"            
    }

    $reqUri = $reqUri + $fieldSep + "offset=$offset&size=$size"
    $fieldSep = "&"
    
    if ($fields) {
        If ($fields.count -gt 1) {
            $reqUri = $reqUri + "&fields=" + ($fields -join ",").ToString()
        } Else {
            $reqUri = $reqUri + "&fields=" + $fields[0]
        }
    }

    
    
    $result = Invoke-RestMethod -Method Get -Uri $reqUri -Headers $(Get-Header) -ContentType "application/json" -UserAgent $userAgent

    if ($all -and $result.total -gt $size) {
        $total = $result.total
        $i = $size
        for($i; $i -lt $total; $i += $size) {
            if($enabled) {
                $result.Mailboxes += (Get-RSMBList -offset $i -fields $fields -enabled).mailboxes
            } else {
                $result.Mailboxes += (Get-RSMBList -offset $i -fields $fields).mailboxes
            }
        }
    }


    return $result
        

}

Function Grant-RSMbPermission {
    Param(
        $mailboxName,
        $permissionUser
    )

    $reqUri = $mbBaseUri + "/" + $mailboxName + "/permissions/" + $permissionUser
    $reqBody = @{permission = 'fullaccess'}

    $result = Invoke-RestMethod -Method Post -Uri $reqUri -Headers $(Get-Header) -ContentType "application/x-www-form-urlencoded" -UserAgent $userAgent -Body $reqBody

    return $result

}

Function Remove-RSMbPermission {
    Param(
        $mailboxName,
        $permissionUser
    )
    
    $reqUri = $mbBaseUri + "/" + $mailboxName + "/permissions/" + $permissionUser
    $reqBody = @{permission = 'fullaccess'}

    $result = Invoke-RestMethod -Method Delete -Uri $reqUri -Headers $(Get-Header) -ContentType "application/x-www-form-urlencoded" -UserAgent $userAgent -Body $reqBody
    return $result
}

Enum MBListFields {
    size    
    currentUsage
    hasBlackBerryMobileService
    hasActiveSyncMobileService
}

$userKey = "VNFfRRxbY83XQzKSFR5K"
$secretKey = "vXLmnPsJJcBY56WFtVRJTY/3DvV741Nnb89Jqbt7"
$userAgent = ([Microsoft.PowerShell.Commands.PSUserAgent]::Chrome)
$baseUri = "https://api.emailsrvr.com/v1/customers/1330469/domains/radpartners.com"
$mbBaseUri = $baseUri + "/ex/mailboxes"
$contactsUri = $baseUri + "/ex/contacts"