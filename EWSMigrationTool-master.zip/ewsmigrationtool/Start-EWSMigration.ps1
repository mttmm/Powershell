Param(
    [string]$MigrationFile = "$PSScriptRoot\MigrationTargets.csv",
    [string]$TargetCredFile = "$PSScriptRoot\creds\RP.mailmigrator.credential",
    [string]$SourceCredFile = "$PSScriptRoot\creds\CRC.epicenter.credential"
)



#$SourceEWSUrl = "https://EAST.EXCH040.serverdata.net/EWS/Exchange.asmx"
$SourceEWSUrl = "https://mail.columbusrad.com/EWS/Exchange.asmx"
$TargetEWSUrl = "https://mex06.emailsrvr.com/ews/exchange.asmx"

$SourceCredential = Import-Clixml $SourceCredFile
$TargetCredential = Import-Clixml $TargetCredFile
#$COACredential = Import-Clixml $COACredFile

Import-Module "$PSScriptRoot\lib\PoshRSJob\PoshRSJob"


$migrationList = Import-CSV -Path $MigrationFile

## Todo Extract Exclusions from CSV

foreach ($entry in $migrationList) {

    ## Todo Add multiple threads

    & $PSScriptRoot\Invoke-EWSMigration.ps1 -SourceMailbox $entry.SourceMailbox -TargetMailbox $entry.TargetMailbox -SourceCredential $SourceCredential -TargetCredential $TargetCredential -SourceEwsUrl $SourceEWSUrl -TargetEwsUrl $TargetEWSUrl

}